# Software-Verification-and-Validation
# SWE202 Homework 1

This is a simple Java application created for the SWE202 - Software Verification and Validation course.

## Description
This application simply prints a welcome message to the console. It is used to practice Git and GitHub.

## How to Run
1. Compile the program: `javac Main.java`
2. Run the program: `java Main`

## Author
suude nas çetin
